<?php

namespace src\demo1;

class Calculatrice
{
    public function add(float $a, float $b): float
    {
        return $a + $b;
    }
}