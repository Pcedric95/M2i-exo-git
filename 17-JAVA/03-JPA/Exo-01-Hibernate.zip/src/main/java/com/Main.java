package com.magasin;

import com.magasin.dao.ArticleDAO;
import com.magasin.model.ArticleMode;
import java.time.LocalDate;




public class Main {
    public static void main(String[] args) {


        // Création d'un nouvel article ArticleMode (t-shirt)

        ArticleMode articleMode = new ArticleMode(
                "T-shirt Homme rouge",
                15.99,
                LocalDate.now(),
                "Homme",
                "L"

        );

        // Initialisation du DAO
        ArticleDAO articleDAO = new ArticleDAO();

        // Ajout de l'article dans la base de données
        articleDAO.save(articleMode);
        System.out.println("T-shirt ajouté avec succès ! ID : " + articleMode.getId());

        // Consultation de l'article
        ArticleMode retrievedTshirt = (ArticleMode) articleDAO.findById(articleMode.getId());
        if (retrievedTshirt != null) {
            System.out.println("Article récupéré : " + retrievedTshirt.getDescription() +
                    ", Catégorie : " + retrievedTshirt.getCategorie() +
                    ", Taille : " + retrievedTshirt.getTaille());
        }

        // Fermeture de la SessionFactory
        articleDAO.close();
    }
}