package com.magasin.model;

import lombok.*;
import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "articles_mode")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleMode extends Article {
    private String categorie; // homme, femme, enfant
    private String taille; // S, M, L, etc.

    public ArticleMode(String descriptiono, double prix, LocalDate now, String categorie, String taille) {
    }
}