package org.example.exo06_api_gestion_meubles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exo06ApiGestionMeublesApplication {

    public static void main(String[] args) {
        SpringApplication.run(Exo06ApiGestionMeublesApplication.class, args);
    }

}
