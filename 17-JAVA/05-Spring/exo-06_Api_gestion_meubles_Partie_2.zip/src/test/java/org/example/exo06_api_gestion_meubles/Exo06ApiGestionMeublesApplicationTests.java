package org.example.exo06_api_gestion_meubles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exo06ApiGestionMeublesApplicationTests {

    @Test
    void contextLoads() {
    }

}
